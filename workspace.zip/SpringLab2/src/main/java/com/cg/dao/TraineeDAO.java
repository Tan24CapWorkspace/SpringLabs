package com.cg.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;

@Repository
public interface TraineeDAO{
	public boolean add(Trainee trainee);
	public boolean delete(Trainee trainee);
	public Trainee find(Integer id);
	public List<Trainee> getAll();
	public Trainee update(Trainee trainee);
}

