package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Trainee;
import com.cg.service.TraineeService;
import com.cg.service.TraineeServiceImpl;

@Controller
@RequestMapping("/home")
// http://localhost:8081/home
public class HomeController {
	
	private TraineeService service = new TraineeServiceImpl();
	
	// http://localhost:8081/home/login
	@PostMapping("/login")
	public ModelAndView login(@RequestParam String user,
							  @RequestParam String pass) {
		ModelAndView mv;
		if(user.equals("") && pass.equals("")) {
			mv = new ModelAndView("home");
		}else {
			mv = new ModelAndView("login");
			mv.addObject("message", "Login credentials invalid");
		}
		return mv;
	}
	
	// http://localhost:8081/home/addshow
	@GetMapping("/addshow")
	public ModelAndView addshow() {
		ModelAndView mv = new ModelAndView("addshow","trainee", new Trainee());
		return mv;
	}
	
	// http://localhost:8081/home/addtrainee
	@PostMapping("/addtrainee")
	public String addtrainee(@ModelAttribute Trainee trainee, BindingResult result, Model model) {
		if(service.findTrainee(trainee.getId())==null && service.addTrainee(trainee)) {
			model.addAttribute("message", "Trainee \n"+trainee+" \nsuccessfully added");
		}else {
			model.addAttribute("message", "Trainee Not added");
		}
		return "home";
	}
	
	@GetMapping("/deleteshow")
	public ModelAndView deleteshow() {
		return new ModelAndView("deleteshow");
	}
	
	@PostMapping("/deletefinal")
	public ModelAndView deletefinal(@RequestParam Integer id) {
		ModelAndView mv;
		service.deleteTrainee(service.findTrainee(id));
		mv = new ModelAndView("home");
		mv.addObject("message", "Trainee deleted successfully");
		return mv;
	}
	
	@PostMapping("/delete")
	public ModelAndView delete(@RequestParam Integer id) {
		ModelAndView mv;
		Trainee temp = service.findTrainee(id);
		if(temp!=null) {
			mv = new ModelAndView("deleteconfirm");
			mv.addObject("tra", temp);
		}else {
			mv = new ModelAndView("home");
			mv.addObject("message", "No Trainee present with id : "+id);
		}
		return mv;
	}
	
	
	@GetMapping("/modifyshow")
	public ModelAndView modifyshow() {
		return new ModelAndView("modifyshow");
	}
	
	@PostMapping("/modify")
	public ModelAndView modify(@RequestParam Integer id) {
		Trainee temp = service.findTrainee(id);
		ModelAndView mv;
		if(temp!=null) {
			mv = new ModelAndView("modify", "trainee", temp);
			return mv;
		}else {
			mv = new ModelAndView("modifyshow");
			mv.addObject("message", "No Trainee present with id "+id);
			return mv;
		}
	}
	
	@PostMapping("/modifyfinal")
	public String modifyfinal(@ModelAttribute Trainee trainee, BindingResult result, Model model) {
		Trainee temp = service.updateTrainee(trainee);
		if(temp!=null) {
			model.addAttribute("message", temp.toString() + " Updated successfully");
		}else {
			model.addAttribute("message", "Updation Fail");
		}
		return "home";
	}
	
	
	@GetMapping("/getshow")
	public ModelAndView getshow() {
		return new ModelAndView("getshow");
	}
	
	@PostMapping("/retrieve")
	public ModelAndView retrieve(@RequestParam Integer id) {
		ModelAndView mv;
		Trainee temp = service.findTrainee(id);
		if(temp!=null) {
			mv = new ModelAndView("retrieve");
			mv.addObject("tra", temp);
		}else {
			mv = new ModelAndView("home");
			mv.addObject("message", "No Trainee present with id : "+id);
		}
		return mv;
	}
	
	@GetMapping("/getallshow")
	public ModelAndView getallshow() {
		List<Trainee> list = service.getAllTrainee();
		if(list!=null) {
			return new ModelAndView("getall","list",list);
		}else {
			ModelAndView mv = new ModelAndView("getall");
			mv.addObject("message", "No Trainee present");
			return mv;
		}
	}
	
}
